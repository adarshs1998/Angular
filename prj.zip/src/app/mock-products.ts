import{Product} from './product';

export const PRODUCTS: Product[]=[
  {id:1, name:"Realme", cost:18400, image:"assets/images/realme.jpg"},
  {id:2, name:"Iphone", cost:19000,image:"assets/images/download.jpg"},
  {id:3, name:"Moto", cost:18000,image:"assets/images/moto.jpg"},
  {id:4, name:"Samsung", cost:15000,image:"assets/images/samsung.jpg"},
  {id:5, name:"Nokia", cost:16000,image:"assets/images/nokia.jpg"},
  {id:6, name:"Oneplus", cost:1400,image:"assets/images/oneplus.jpg"},
  {id:7, name:"Redmi", cost:18020,image:"assets/images/redmi.jpg"}
];
